package isamm.projet.inter;

import java.util.List;

public interface IDao <I>{
	public boolean create (I obj);
	public List getAll();
	public int delete(int id);
	public boolean update(int id,I obj );
	public boolean getById(int id);
}
